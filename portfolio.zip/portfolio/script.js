document.getElementById('y').textContent=new Date().getFullYear();
const lb=document.getElementById('lb'),lbImg=lb.querySelector('img');
document.querySelectorAll('.masonry button').forEach(b=>b.addEventListener('click',()=>{
  lbImg.src=b.dataset.src;lbImg.alt=b.querySelector('img').alt;lb.showModal();
}));
lb.addEventListener('click',()=>lb.close());
